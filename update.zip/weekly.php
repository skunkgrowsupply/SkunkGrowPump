
<?php

// if no brand set, redirect to brands page
$brandSettingFileName = "brandset.txt";
if (!file_exists($brandSettingFileName)) {
	header('Location: brands.php');
	die();
}

// dispenseNutrients()
require_once('functions.php');

// while debug mode is on, display details at bottom of webpage
$debugModeOn = False;

// enable verbose error reporting for debugging
if ($debugModeOn) {
	error_reporting(-1);
	ini_set('display_errors', 'On');
}

// if tanksize.txt doesn't yet exist, create it and initialize a default tank size
$fileName = "tanksize.txt";
if (!file_exists($fileName)) {
	$tankSizeFile = fopen($fileName, "w");
	$defaultTankSize = 5;
	fwrite($tankSizeFile, $defaultTankSize);
	fclose($tankSizeFile);
}

// if tank size is updated by user, save change to tanksize.txt
if (isset($_POST['updateTankSize'])) {
	$tankSizeFile = fopen($fileName, "w");
	fwrite($tankSizeFile, $_POST['tankSize']);
	fclose($tankSizeFile);
}

// if chart is updated by user, save change to chartset.txt
$chartSettingFileName = "chartset.txt";
if ( isset( $_POST['updateChart'] ) && isset( $_POST['chart'] ) ) {
	$chartSettingFile = fopen($chartSettingFileName, "w");
	fwrite($chartSettingFile, $_POST['chart']);
	fclose($chartSettingFile);
}

// read brand setting
$brandSettingFile = fopen($brandSettingFileName, "r");
$brandDir = fgets($brandSettingFile);
fclose($brandSettingFile);

?>

<html>

<head>
<!-- <link rel="stylesheet" href="style.css"> -->
<!-- <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'> -->
<title>Skunk Dosing Center</title>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
<style>
.submit {
  border: none;
  padding: 0;
  background: none;
}
</style>
</head>

<body>
<div align="center">
<b><font color='08a329'>Connect to http://skunkgrowpump.local          or           http://
<?php system("hostname -I"); ?>
</font></div>
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<tr>
<td>
	<a href="index.php" alt="Manual Dosing"><img src="images/manual.png" height="100" width="170"></a>
</td>
<td>
    <a href="brands.php" alt="Brands"><img src="images/brands.png" height="100" width="170"></a>
</td>
<td>
   	<a href="weekly.php" alt="Weekly Dosing"><img src="images/weekly.png" height="100" width="170"></a>
</td>
<td>
    <a href="settings.php" alt="Settings"><img src="images/settings.png" height="100" width="170"></a>

</td>
</tr>

</tbody>
</table>

<table class="centerTable" style="margin: 0px auto;width: 698px;table-layout: fixed;">
<tbody>

<tr>
	<td colspan="4">
		<div>
			<div style="display:inline-block; width:50%; vertical-align: middle;">
				<div>
					<form method="post">
						<div>
							<label><strong>Tank Size (in Gallons):</strong></label>
						</div>
						<div style="display:flex;">
							<?php
								// read and populate tank size in tankSize input field
								$tankSizeFile = fopen($fileName, "r");
								$tankSize = fgets($tankSizeFile);
								fclose($tankSizeFile);
								echo '<input type="number" name="tankSize" value="' . $tankSize . '" id="tankSize" min="1" style="height: 30px; width:100%;font-size: 1em;">';
							?>
							<button type="submit" name="updateTankSize" style="margin: 0px 10px 0px 10px; width:95px"><img src="images/update.png" height="25" width="60"></button>
						</div>
					</form>
				</div>
				<div>
					<form method="post" style="margin-bottom: 0;">
					    <div>
							<label><strong>Selected Chart:</strong></label>
						</div>
						<div style="display:flex;">
							<select name="chart" id="chart" style="height: 30px; width: 100%; -webkit-appearance: menulist-button; font-size: 1em;">
								<option selected disabled><b>Select Chart</b></option>
								<?php
									// read chart setting
									$chartSettingFile = fopen($chartSettingFileName, "r");
									$chartSetting = fgets($chartSettingFile);
									fclose($chartSettingFile);
						
									$pathToBrandCharts = dirname(__FILE__) . '/brands/' . $brandDir . '/';
									$files = scandir($pathToBrandCharts);
									foreach ($files as $file) {
										$pathToBrandChart = $pathToBrandCharts . $file;
										$pInfo = pathinfo($pathToBrandChart);
										if (is_file($pathToBrandChart) && $pInfo['extension'] == 'xml') {
											$optionBuilderStr = '<option value="' . $file . '"';
									
											if ($file == $chartSetting) {
												$optionBuilderStr .= ' selected';							
											}
									
											$optionBuilderStr .= '>' . $pInfo['filename'] . '</option>';
											echo $optionBuilderStr;
										}
									}
								?>
							</select>
							<button type="submit" name="updateChart" style="margin: 0px 10px 0px 10px; width:95px"><img src="images/update.png" height="25" width="60"></button>
						</div>
					</form>
				</div>
			</div>
			<div style="display:inline-block; text-align: right; width:49%; vertical-align: middle;">
				<div style="display:inline-block;">
					<div>
						<?php
							// populate brand image
							$brandImageFilePath='brands/' . $brandDir . '/toplogo.png';
							echo '
								<img src="'. $brandImageFilePath .'" id="brandImage" height="100" width="300">
							';
						?>
					</div>
					<div style="padding-right: 1em;">
						<a href="setup.php" style="font-size: 1.2em;text-decoration: none;color: black;"><img src="images/setuppumps.png" height="45" width="140"></a>
					</div>
				</div>
			</div>
		</div>
	</td>
</tr>

</tbody>
</table>

<?php
	// check for existance of chart setting
	clearstatcache();
	if (filesize($chartSettingFileName) == 0) {
		if ($debugModeOn) {
			echo '<strong>No chart selected!</strong><br>';
		}
		die();
	}

	// test XML chart for conformity to schema
	try {
		$xml = new DOMDocument();
	} catch (Exception $e) {
		echo 'PHP XML/DOM extension not found! Please visit '.
			'<a href="https://www.php.net/manual/en/dom.installation.php">'.
			'https://www.php.net/manual/en/dom.installation.php</a>'.
			' for installation instructions.<br>';
		die();
	}
	$xml->load($pathToBrandCharts . $chartSetting);

	// disable libxml errors (for DOMDocument::schemaValidate()) and allow user to fetch error information as needed
	libxml_use_internal_errors(true);

	$schemaPath = 'scheduleDefinition.xsd';
	if( !$xml->schemaValidate($schemaPath) ) {
		echo '<strong>Invalid chart selected (non-conformant XML)!</strong><br>';
	// 	echo print_r( libxml_get_errors() );
		die();
	}

	$xml = simplexml_load_file($pathToBrandCharts . $chartSetting) or die("Error: Cannot create object from XML");

	if ($debugModeOn) {
		echo '<em>Imported XML Data</em><br>';
	}

	$chartData = array();
	foreach ($xml as $chartWeek) {
		if ($debugModeOn) {
			echo '<strong>Chart Week: ' . $chartWeek['number'] . '</strong><br>';
		}
		$chartWeekNumber = intval($chartWeek['number']);
		
		$chartData[$chartWeekNumber]['seqData'] = array();
		$chartData[$chartWeekNumber]['nutrientNames'] = array();
		$chartData[$chartWeekNumber]['note'] = $chartWeek->note;

		foreach ($chartWeek->nutrient as $chartNutrient) {
			if ($debugModeOn) {
				echo 'Nutrient Name: ' . $chartNutrient['name'] . '<br>';
				echo 'GPIO Channel #' . $chartNutrient->gpio . '<br>';
				echo 'Nutrient Ratio: ' . $chartNutrient->dpg . ' mL/gal <br>';
				echo 'Post-Pump Delay: ' . intval( $chartNutrient->delay ) . 's <br><br>';
			}
			array_push( $chartData[$chartWeekNumber]['seqData'], array( intval( $chartNutrient->gpio ),
						floatval( $chartNutrient->dpg ), intval( $chartNutrient->delay ) ) );
			array_push( $chartData[$chartWeekNumber]['nutrientNames'], $chartNutrient['name'] );
		}
	}
	
	for ($i = 1; $i <= count($chartData); $i++) {
		if( !isset($chartData[$i]) ) {
			echo '<strong>Invalid chart selected! Chart must contain data for all weeks from first to last!</strong><br>';
			die();
		}
	}
	
?>

<form method="post" align="center">
<?php

	for ($i = 1; $i <= count($chartData); $i++) {
		if ($i != 1) {
			echo '<hr style="background-color: #08a42a; height: 2px; max-width:60%;">';
		}
		
		echo '
			<div>
				<button type="submit" name="week" class="submit" value=' . $i .
				'><img src="images/weekly/week' . $i . '.jpg" height="120" width="600"></button>
			</div>
		';
		
		echo '<div class="nutrient-list" style="font-family: Comic Sans MS, cursive, sans-serif; font-size: 1.1em;">';
		
		$nutrientCount = 1;
		$nutrientsPerLine = 5;
		$firstInSeq = True;
		foreach ($chartData[$i]['nutrientNames'] as $key => $nutrientName) {
			if ($firstInSeq) {
				$firstInSeq = False;
			} else {
				echo ' | ';
			}
			
			echo $nutrientName . ': ' . $chartData[$i]['seqData'][$key][1] . ' mL';
			
			if ($nutrientCount % $nutrientsPerLine == 0) {
				echo '<br>';
				$firstInSeq = True;
			}
			$nutrientCount++;
		}
		
		echo '</div>';

		if ( $chartData[$i]['note'] != '' ){
			echo '<div class="note" style="font-family: Comic Sans MS, cursive, sans-serif; font-size: 1.1em;">';
			echo 'NOTE: ';
			echo $chartData[$i]['note'];
			echo '</div>';
		}
	}
?>

</form>
</body>

</html>

<?php

// handle scenario where no week button pressed
if (!isset($_POST['week'])) {
	if ($debugModeOn) {
		echo '<strong>No week selected!</strong><br>';
	}
	die();
}

if ($debugModeOn) {
	echo '<em>Dispensing Sequence</em><br>';
}

$week = $_POST['week'];
if ($debugModeOn) {
	echo '<strong>Week #'.$week.'</strong><br>';
}

// 2D array of GPIO channel #s and their corresponding dose/gallon settings
$sequence = $chartData[$week]['seqData'];
dispenseNutrientsWithCustomDelay($sequence, $tankSize, $debugModeOn);

