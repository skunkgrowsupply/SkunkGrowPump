
import RPi.GPIO as GPIO
import time
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-g", type=int, required=True, help="GPIO Channel #")
parser.add_argument("-t", type=float, required=True, help="Pump Run Time (in s)")
args = parser.parse_args()

gpioChannel = args.g
pumpRunTime = args.t

GPIO.setmode(GPIO.BCM)

GPIO.setup(gpioChannel, GPIO.OUT)

print("GPIO Channel #{}".format(gpioChannel))

print("Scheduled Pump Run Time: {}s".format(pumpRunTime))

print("START:\t{} {}".format(time.ctime(), time.localtime().tm_zone))

GPIO.output(gpioChannel, 1)

time.sleep(pumpRunTime)

GPIO.output(gpioChannel, 0)

print("END:\t{} {}".format(time.ctime(), time.localtime().tm_zone))
print()
