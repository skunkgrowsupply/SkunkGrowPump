<?php

function dispenseNutrients($seq, $tSize, $debugModeOn) {
	foreach ($seq as &$i) {
		// dispense nutrients with zero delay
		array_push($i, 0);
	}
	dispenseNutrientsWithCustomDelay($seq, $tSize, $debugModeOn);
}

function dispenseNutrientsWithCustomDelay($seqWithDelays, $tankSizeInGal, $debugModeOn) {
	// iterate over array to construct sequence to call pumpForDuration()
	$sequence = array();
	foreach ($seqWithDelays as $i) {
		$gpio = $i[0]; 	// gpio #
		$dpg = $i[1]; 	// dose per gallon (in mL)
		$delay = $i[2]; // delay (in sec)
		
		$dispenseTime = $dpg / 10 * 5.65 * $tankSizeInGal;
		
		if ($debugModeOn) {
			echo 'GPIO Channel #' . $gpio . '<br>';
			echo 'Nutrient Ratio: ' . $dpg . ' mL/gal<br>';
			echo 'Tank Size: ' . $tankSizeInGal . ' gal<br>';
			echo 'Scheduled Nutrient Dispense Time: ' . $dispenseTime . ' s <br><br>';
		}
		
		array_push($sequence, array( $gpio, $dispenseTime, $delay ));
	}
	
	pumpForDurationWithCustomDelay($sequence, $debugModeOn);
	
}

function pumpForDuration($seq, $debugModeOn) {
	foreach ($seq as &$i) {
		// pump with zero delay
		array_push($i, 0);
	}
	
	pumpForDurationWithCustomDelay($seq, $debugModeOn);
	
}

function pumpForDurationWithCustomDelay($seqWithDelays, $debugModeOn) {
	$iteration = 1;
	$cmdStrBuilder = '(';
	
	foreach ($seqWithDelays as $pump) {
		$gpio = $pump[0]; 		// gpio #
		$duration = $pump[1]; 	// duration (in sec)
		$delay = $pump[2]; 		// delay (in sec)
	
		if ($debugModeOn) {
			echo 'GPIO Channel #' . $gpio . '<br>';
			echo 'Run for <strong>' . $duration . '</strong> s <br><br>';
			echo 'Post-pump delay: ' . $delay . ' s <br><br>';
		}
		
		$pythonInterpreterPath = '/usr/bin/python3';
		$pythonScriptPath = 'runPump.py';
		$pythonOutputLogPath = 'pylog.txt';
		
		$cmdStrBuilder .= $pythonInterpreterPath . ' ' . $pythonScriptPath .
							' -g ' . $gpio .
							' -t ' . $duration .
							' >> ' . $pythonOutputLogPath . ' 2>&1';
						
		if ($iteration != count($seqWithDelays)) {
			$cmdStrBuilder .= ' && sleep ' . $delay . ' && ';
		}
							
		$iteration++;
	}
	
	$cmdStrBuilder .= ') >>/dev/null 2>&1 &';
	
	if ($debugModeOn) {
		echo $cmdStrBuilder . '<br><br>';
	}
	
	exec($cmdStrBuilder);
	
}

