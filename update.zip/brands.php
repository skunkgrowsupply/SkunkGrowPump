
<html>

<head>
<!-- <link rel="stylesheet" href="style.css"> -->
<!-- <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'> -->
<title>Skunk Dosing Center</title>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
<style>
.submit {
  border: none;
  padding: 0;
  background: none;
}
</style>
</head>

<body>
<div align="center">
<b><font color='08a329'>Connect to http://skunkgrowpump.local          or           http://
<?php system("hostname -I"); ?>
</font></div>
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<tr>
<td>
	<a href="index.php" alt="Manual Dosing"><img src="images/manual.png" height="100" width="170"></a>
</td>
<td>
    <a href="brands.php" alt="Brands"><img src="images/brands.png" height="100" width="170"></a>
</td>
<td>
   	<a href="weekly.php" alt="Weekly Dosing"><img src="images/weekly.png" height="100" width="170"></a>
</td>
<td>
    <a href="settings.php" alt="Settings"><img src="images/settings.png" height="100" width="170"></a>

</td>
</tr>

</tbody>
</table>
<form method="post" align="center">
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<?php

// while debug mode is on, display details at bottom of webpage
$debugModeOn = False;

// enable verbose error reporting for debugging
if ($debugModeOn) {
	error_reporting(-1);
	ini_set('display_errors', 'On');
}

$pathToBrandDirs = dirname(__FILE__).'/brands/';
$dirs = array_diff(scandir($pathToBrandDirs), array('..', '.'));
$colIndex = 1;
$colsPerRow = 1;

foreach ($dirs as $dir) {
	$pathToBrandDir = $pathToBrandDirs . $dir;
	if (is_dir($pathToBrandDir)) {
		if ($debugModeOn) {
			echo 'Path: ' . $pathToBrandDir . '<br>';
			echo 'Dir Name: ' . $dir . '<br>';
		}
		
		if ($colIndex % $colsPerRow == 1) {
			echo '<tr>';
		}
		
		echo '
			<td>
				<button type="submit" name="brand" class="submit" value="' . $dir .
				'"><img src="brands/' . $dir . '/logo.png" height="100" width="500"></button>
			</td>
		';
		
		if ($colIndex % $colsPerRow == 0) {
			echo '</tr>';
		}
		$colIndex++;
	}
}

if ($colIndex > 1 && $colIndex % 4 != 1) {
	echo '</tr>';
}

?>

</tbody>
</table>
</form>

</body>

</html>

<?php

// if not brand was selected, proceed no further
if (!isset($_POST['brand'])) {
	die();
}

// Overwrite brandset.txt to save selected brand setting
$brandSettingFileName = "brandset.txt";
$brandSettingFile = fopen($brandSettingFileName, "w");
fwrite($brandSettingFile, $_POST['brand']);
fclose($brandSettingFile);

// Overwrite chartset.txt to clear/reset previous chart setting
$chartSettingFileName = "chartset.txt";
$chartSettingFile = fopen($chartSettingFileName, "w");
fclose($chartSettingFile);

header('Location: weekly.php');
