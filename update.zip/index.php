
<?php 

// dispenseNutrients()
require_once('functions.php');

// while debug mode is on, display details at bottom of webpage
$debugModeOn = False;

// enable verbose error reporting for debugging
if ($debugModeOn) {
	error_reporting(-1);
	ini_set('display_errors', 'On');
}

?>

<html>

<head>
<!-- <link rel="stylesheet" href="style.css"> -->
<!-- <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'> -->
<title>Skunk Dosing Center</title>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
<style>
.submit {
  border: none;
  padding: 0;
  background: none;
}
.size-36 {
font-size: 36px;
}

.size-12 {
font-size: 12px;
}
</style>
</head>

<body>
<div align="center">
<b><font color='08a329'>Connect to http://skunkgrowpump.local          or           http://
<?php system("hostname -I"); ?>
</font></div>
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<tr>
<td>
	<a href="index.php" alt="Manual Dosing"><img src="images/manual.png" height="100" width="170"></a>
</td>
<td>
    <a href="brands.php" alt="Brands"><img src="images/brands.png" height="100" width="170"></a>
</td>
<td>
   	<a href="weekly.php" alt="Weekly Dosing"><img src="images/weekly.png" height="100" width="170"></a>
</td>
<td>
    <a href="settings.php" alt="Settings"><img src="images/settings.png" height="100" width="170"></a>
</td>
</tr> 

</tbody>
</table>

<div style="margin: 0 auto; width:600px;">
	<div style="float: left;">
		<form method="post">
		<div style="margin-bottom: 5px;">
			<label style="float: left; width: 150px; font-size: 1em;">Select Nutrient Pump: </label>
			<select name="gpio" id="gpio" style="width: 120px; height: 30px; -webkit-appearance: menulist-button; font-size: 1em;">
				<option value="20">1</option>
				<option value="21">2</option>
				<option value="26">3</option>
				<option value="23">4</option>
				<option value="19">5</option>
				<option value="24">6</option>
				<option value="22">7</option>
				<option value="27">8</option>
				<option value="12">9</option>
				<option value="25">10</option>
			</select>
		</div>
		<div>
			<label style="float: left; width: 150px;">Dose (in mL): </label>
			<input type="number" name="dose" id="dose" min="1" step=0.1 style="width: 120px;height: 30px;font-size: 1em;"">
		</div>
		<div style="clear:both;text-align:center;margin-top: 12px;">
			<button type="submit" name="dispenseBtn" style="font-size: 1em;" class="submit"><img src="images/dispense.png" height="70" width="250"></button>
		</div>
		</form>
	</div>
	<div style="float: right;">
		<form method="post">
		<div style="margin-bottom: 5px;">
			<label style="float: left; width: 175px;">Select Water Pump: </label>
			<select name="water-pump-gpio" id="water-pump-gpio" style="width: 125px; height: 30px; -webkit-appearance: menulist-button; font-size: 1em;">
				<?php
					$numberOfWaterPumps = 5;
					$waterPumpDropDownValues = array(16, 13, 6, 5, 17);
				
					$fileName = 'waterPumpNicknames.txt';
					$waterPumpNicknamesFile = fopen($fileName, "r");
					for ($i = 0; $i < $numberOfWaterPumps; $i++) {
						$elementBuilderStr  = '<option value="' . $waterPumpDropDownValues[$i];
						$elementBuilderStr .= '">' . ($i + 1);
						
						if (($waterPumpNickname = fgets($waterPumpNicknamesFile)) !== false) {
							 $elementBuilderStr .= ' - ' . $waterPumpNickname;
						}
						$elementBuilderStr .= '</option>';
						
						echo $elementBuilderStr;
					}
					fclose($waterPumpNicknamesFile);
				?>
			</select>
		</div>
		<div>
			<label style="float: left; width: 125px;">Run time:     </label>
			<div style="" align="right">
				<label>H</label>
				<input type="number" class="size-36" name="run-time-h" id="run-time-h" min="0" style="width: 40px;height: 30px; font-size: 1em;">
				<label>M</label>
				<input type="number" class="size-36" name="run-time-m" id="run-time-m" min="1" max="59" style="width: 40px;height: 30px; font-size: 1em;">
			</div>
		</div>
		<div style="clear:both;text-align:center;margin-top: 12px;">
			<button type="submit" name="waterPumpRunBtn" style="font-size: 1em;" class="submit"><img src="images/runpump.png" height="70" width="250"></button>
		</div>
		</form>
		<br>

	</div>
</div>

<hr style="clear: both;max-width:90%;">

<form method="post" align="center">

<table  class="centerTable" style="margin: 0px auto;">
<tbody>
<tr>
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p1.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=1><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=2><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=3><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=4><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=5><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p2.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=6><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=7><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=8><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=9><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=10><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p3.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=11><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=12><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=13><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=14><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=15><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p4.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=16><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=17><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=18><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=19><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=20><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p5.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=21><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=22><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=23><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=24><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=25><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p6.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=26><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=27><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=28><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=29><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=30><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">	
	<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p7.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=31><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=32><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=33><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=34><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=35><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p8.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=36><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=37><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=38><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=39><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=40><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p9.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=41><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=42><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=43><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=44><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=45><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
<tr>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
<td align="center">
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/p10.jpg" height="90" width="100"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=46><img src="images/dosepump/5ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=47><img src="images/dosepump/10ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=48><img src="images/dosepump/20ml.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=49><img src="images/dosepump/30ml.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=50><img src="images/dosepump/50ml.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td>
		<img src="images/waterpump/w1.jpg" height="90" width="100" style="margin: 2px;">
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=51><img src="images/waterpump/5min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=52><img src="images/waterpump/15min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=53><img src="images/waterpump/30min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=54><img src="images/waterpump/1hour.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=55><img src="images/waterpump/2hour.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td>
		<img src="images/waterpump/w2.jpg" height="90" width="100" style="margin: 2px;">
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=56><img src="images/waterpump/5min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=57><img src="images/waterpump/15min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=58><img src="images/waterpump/30min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=59><img src="images/waterpump/1hour.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=60><img src="images/waterpump/2hour.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td>
		<img src="images/waterpump/w3.jpg" height="90" width="100" style="margin: 2px;">
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=61><img src="images/waterpump/5min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=62><img src="images/waterpump/15min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=63><img src="images/waterpump/30min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=64><img src="images/waterpump/1hour.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=65><img src="images/waterpump/2hour.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td>
		<img src="images/waterpump/w4.jpg" height="90" width="100" style="margin: 2px;">
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=66><img src="images/waterpump/5min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=67><img src="images/waterpump/15min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=68><img src="images/waterpump/30min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=69><img src="images/waterpump/1hour.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=70><img src="images/waterpump/2hour.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<tbody>
		<tr>
			<td align="center"><img src="images/divider.png" height="15" width="620"></td>
		</tr>
	</tbody>
</table>
<table  class="centerTable" style="margin: 0px auto;">
	<td>
		<img src="images/waterpump/w5.jpg" height="90" width="100" style="margin: 2px;">
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=71><img src="images/waterpump/5min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=72><img src="images/waterpump/15min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=73><img src="images/waterpump/30min.jpg" height="90" width="110"></button>
	</td>
	<td>
		<button type="submit" name="preset" class="submit" value=74><img src="images/waterpump/1hour.jpg" height="90" width="110"></button>
	</td>
		<td>
		<button type="submit" name="preset" class="submit" value=75><img src="images/waterpump/2hour.jpg" height="90" width="110"></button>
	</td>
</tr>
</tbody>
</table>
</form>

</body>

</html>

<?php

$tankSize = 1; // tank size of 1 gallon chosen to prevent dose scaling

if (isset($_POST['dispenseBtn'])) {
	echo '
		<script>
			document.getElementById("gpio").value="' . $_POST['gpio'] . '";
			document.getElementById("dose").value="' . $_POST['dose'] . '";
		</script>
		 ';
	// 2D array of gpio channel #s and their corresponding dose/gallon settings
	$sequence = array (
		array($_POST['gpio'], $_POST['dose'])
	);
	dispenseNutrients($sequence, $tankSize, $debugModeOn);
}

if (isset($_POST['waterPumpRunBtn'])) {
	echo '
		<script>
			document.getElementById("water-pump-gpio").value="' . $_POST['water-pump-gpio'] . '";
			document.getElementById("run-time-h").value="' . $_POST['run-time-h'] . '";
			document.getElementById("run-time-m").value="' . $_POST['run-time-m'] . '";
		</script>
		 ';
	// 2D array of gpio channel #s and their corresponding dose/gallon settings
	$sequence = array (
		array($_POST['water-pump-gpio'], $_POST['run-time-h'] * 3600 + $_POST['run-time-m'] * 60)
	);
	pumpForDuration($sequence, $debugModeOn);
}

// handle preset button press
$preset = -1; // default preset value (used when no preset button is pressed)
if (isset($_POST['preset']))
	$preset = $_POST['preset'];

switch ($preset) {
	case 1:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(20, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 2:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(20, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 3:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(20, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 4:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(20, 30) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 5:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(20, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 6:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(21, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 7:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(21, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 8:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(21, 20) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 9:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(21, 30)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 10:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(21, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 11:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(26, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 12:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(26, 10) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 13:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(26, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 14:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(26, 30)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 15:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(26, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 16:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(23, 5) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 17:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(23, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 18:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(23, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 19:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(23, 30) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 20:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(23, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 21:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(19, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 22:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(19, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 23:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(19, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 24:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(19, 30) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 25:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(19, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 26:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(24, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 27:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(24, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 28:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(24, 20) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 29:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(24, 30)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 30:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(24, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 31:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(22, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 32:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(22, 10) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 33:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(22, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 34:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(22, 30)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 35:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(22, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 36:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(27, 5) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 37:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(27, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 38:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(27, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 39:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(27, 30) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 40:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(27, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 41:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(12, 5)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 42:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(12, 10) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 43:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(12, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 44:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(12, 30)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 45:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(12, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 46:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(25, 5) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 47:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(25, 10)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 48:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(25, 20)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 49:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(25, 30) // purge
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 50:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their corresponding dose/gallon settings
		$sequence = array (
			array(25, 50)
		);
		dispenseNutrients($sequence, $tankSize, $debugModeOn);
		break;
	case 51:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(16, 300)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 52:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(16, 900)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 53:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(16, 1800)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 54:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(16, 3600)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 55:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(16, 7200)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 56:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(13, 300)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 57:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(13, 900)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 58:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(13, 1800)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 59:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(13, 3600)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 60:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(13, 7200)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 61:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(6, 300)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 62:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(6, 900)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 63:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(6, 1800)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 64:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(6, 3600)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 65:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(6, 7200)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 66:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(5, 300)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 67:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(5, 900)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 68:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(5, 1800)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 69:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(5, 3600)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 70:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(5, 7200)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 71:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(17, 300)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 72:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(17, 900)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 73:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(17, 1800)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 74:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(17, 3600)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	case 75:
		if ($debugModeOn) {
			echo '<strong>Preset #'.$preset.'</strong><br>';
		}
		// 2D array of gpio channel #s and their run times
		$sequence = array (
			array(17, 7200)
		);
		pumpForDuration($sequence, $debugModeOn);
		break;
	default:
		if ($debugModeOn) {
			echo '<strong>No preset selected!</strong><br>';
		}
		break;
	
}



