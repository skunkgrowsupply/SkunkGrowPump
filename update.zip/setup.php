<?php

// pumpForDuration()
require_once('functions.php');

// while debug mode is on, display details at bottom of webpage
$debugModeOn = False;

// enable verbose error reporting for debugging
if ($debugModeOn) {
	error_reporting(-1);
	ini_set('display_errors', 'On');
}

$brandSettingFileName = "brandset.txt";
$brandSettingFile = fopen($brandSettingFileName, "r");
$brandDir = fgets($brandSettingFile);
fclose($brandSettingFile);

?>

<html>

<head>
	<title>Skunk Dosing Center</title>
	<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
	<style>
.submit {
  border: none;
  padding: 0;
  background: none;
}
</style>
</head>

<body>
<div align="center">
<b><font color='08a329'>Connect to http://skunkgrowpump.local          or           http://
<?php system("hostname -I"); ?>
</font></div>
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<tr>
	<td>
		<a href="index.php" alt="Manual Dosing"><img src="images/manual.png" height="100" width="170"></a>
	</td>
	<td>
		<a href="brands.php" alt="Brands"><img src="images/brands.png" height="100" width="170"></a>
	</td>
	<td>
		<a href="weekly.php" alt="Weekly Dosing"><img src="images/weekly.png" height="100" width="170"></a>
	</td>
	<td>
		<a href="settings.php" alt="Settings"><img src="images/settings.png" height="100" width="170"></a>
	</td>
</tr>

</tbody>
</table>

<!-- <center> -->
<div style="text-align:center;">
<?php		
	$imgBuilderStr = '<img src="brands/' . $brandDir . '/toplogo.png" height="100" width="300" />';
	echo $imgBuilderStr;
?>
</div>
<div style="text-align:center;">
Clicking Bottle = Purge Pump
</div>
<table class="centerTable" style="margin: 0px auto;table-layout: fixed;width: 772px;">
<thead>
	<tr>
		<th></th>
		<th></th>
		<th></th>
		<th></th>
		<th></th>
	</tr>
</thead>

<tbody>

<form method="post" align="center">
<?php

	// test XML chart for conformity to schema
	try {
		$xml = new DOMDocument();
	} catch (Exception $e) {
		echo 'PHP XML/DOM extension not found! Please visit '.
			'<a href="https://www.php.net/manual/en/dom.installation.php">'.
			'https://www.php.net/manual/en/dom.installation.php</a>'.
			' for installation instructions.<br>';
		die();
	}
	$xml->load('brands/' . $brandDir . '/purge/purge.xml');

	// disable libxml errors (for DOMDocument::schemaValidate()) and allow user to fetch error information as needed
	libxml_use_internal_errors(true);
	
	$schemaPath = 'purgeDefinition.xsd';
	if( !$xml->schemaValidate($schemaPath) ) {
		echo '<strong>Invalid / non-conformant XML!</strong><br>';
	// 	echo print_r( libxml_get_errors() );
		die();
	}
	
	$xml = simplexml_load_file('brands/' . $brandDir . '/purge/purge.xml') or die("Error: Cannot create object from XML");

	if ($debugModeOn) {
		echo '<em>Imported XML Data</em><br>';
	}
	
	$purgeData = array();
	foreach ($xml as $pump) {
		if ($debugModeOn) {
			echo '<strong>Pump: ' . $pump['number'] . '</strong><br>';
		}
		$pumpNumber = intval($pump['number']);
		$purgeData[$pumpNumber] = array();
		
		if ($debugModeOn) {
			echo 'GPIO Channel #'	. $pump->gpio . '<br>';
			echo 'Duration: ' 		. $pump->duration . ' s <br><br>';
		}
		$purgeData[$pumpNumber] = array( intval( $pump->gpio), floatval( $pump->duration));
	}
	
	if ($debugModeOn) {
		print_r($purgeData);
	}
	
	$colIndex = 1;
	$colsPerRow = 5;
	
	ksort($purgeData);
	foreach ($purgeData as $key => $_) {
			if ($colIndex % $colsPerRow == 1) {
				echo '<tr>';
			}
		
			echo '
				<td>
					<button type="submit" name="pump" class="submit" value=' . $key .
					'><img src="brands/' . $brandDir . '/purge/' . $key . '.png" height="200" width="130"></button>
				</td>
			';
		
			if ($colIndex % $colsPerRow == 0) {
				echo '</tr>';
			}
			$colIndex++;
	}
	
	// TODO: May further validate purge.xml in a future iteration (optional)
?>

</form>
</tbody>
</table>

</body>

</html>

<?php

// handle scenario where no week button pressed
if (!isset($_POST['pump'])) {
	if ($debugModeOn) {
		echo '<strong>No pump selected!</strong><br>';
	}
	die();
}

$pumpNumber = $_POST['pump'];
if ($debugModeOn) {
	echo '<strong>Purging Pump #' . $pumpNumber . '</strong><br>';
}

// 2D array of GPIO channel #s and purge durations in seconds
$sequence = array($purgeData[$pumpNumber]);
pumpForDuration($sequence, $debugModeOn);

