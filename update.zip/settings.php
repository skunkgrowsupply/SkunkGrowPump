<?php

// while debug mode is on, display details at bottom of webpage
$debugModeOn = False;

// enable verbose error reporting for debugging
if ($debugModeOn) {
	error_reporting(-1);
	ini_set('display_errors', 'On');
}

?>

<html>

<head>
	<title>Skunk Dosing Center</title>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
<style>
.submit {
  border: none;
  padding: 0;
  background: none;
}
</style>
</head>

<body>
<div align="center">
<b><font color='08a329'>Connect to http://skunkgrowpump.local          or           http://
<?php system("hostname -I"); ?>
</font></div>
<table class="centerTable" style="margin: 0px auto;">
<tbody>

<tr>
<td>
	<a href="index.php" alt="Manual Dosing"><img src="images/manual.png" height="100" width="170"></a>
</td>
<td>
    <a href="brands.php" alt="Brands"><img src="images/brands.png" height="100" width="170"></a>
</td>
<td>
   	<a href="weekly.php" alt="Weekly Dosing"><img src="images/weekly.png" height="100" width="170"></a>
</td>
<td>
    <a href="settings.php" alt="Settings"><img src="images/settings.png" height="100" width="170"></a>
</td>
</tr>

</tbody>
</table>
<table class="centerTable" style="margin: 0px auto;" width="440">
<tbody>
<tr>
	<td align="center">
		<img src="images/support.jpg" height="70" width="70"><a href="https://www.skunkgrow.com" alt="Website"><img src="images/website.png" height="60" width="160"></a>
	</td>
	<td>
		<a href="https://www.facebook.com/skunkgrowsupply" alt="Facebook"><img src="images/facebook.jpg" height="60" width="60"></a>
	</td>
	<td>
		<a href="https://www.instagram.com/skunkgrowsupply" alt="Instagram"><img src="images/instagram.jpg" height="60" width="60"></a>
	</td>
</tr>
</tbody>
</table>

<div style="text-align: center;margin-top: 10px;">
	<div>
		Last Updated On:
		<br>
		<span id="last-updated-ts">
		<?php
			$fileName = "updateInfo.txt";
			if ( isset($_POST['updateBtn']) ) {
				$updateInfoFile = fopen($fileName, "w");
				fwrite($updateInfoFile, date('m/d/Y h:i:s a') . ' ' . date_default_timezone_get());
				fclose($updateInfoFile);
			}
			
			if ( !file_exists($fileName) ) {
				$updateInfoFile = fopen($fileName, "w");
				fclose($updateInfoFile);
			}
			
			$updateInfoFile = fopen($fileName, "r");
			$lastUpdatedTS = fgets($updateInfoFile);
			fclose($updateInfoFile);
			
			echo $lastUpdatedTS;
		?>
		</span>
		<br>
		<form method="post">
		<button type="submit" class="submit" name="updateBtn"><img src="images/downloadupdate.png" height="50" width="300"></button>
		</form>
	</div>
	<hr style="max-width:90%;">
	<div>
		<em>Customize Water Pump Nicknames</em>
		<br><br>
		<div style="width: 400px; text-align: left; margin: 0 auto;">
			<form method="post">					
				<?php
					$numberOfWaterPumps = 5;
				
					$fileName = 'waterPumpNicknames.txt';
					if ( isset($_POST['updateWaterPumpNickNames']) ) {
						$waterPumpNicknamesFile = fopen($fileName, "w");
	
						for ($i = 1; $i <= $numberOfWaterPumps; $i++) {
							fwrite($waterPumpNicknamesFile, $_POST['water-pump-nn-' . $i] . PHP_EOL);
						}
						fclose($waterPumpNicknamesFile);
					}
					
					if ( !file_exists($fileName) ) {
						$waterPumpNicknamesFile = fopen($fileName, "w");
						fclose($waterPumpNicknamesFile);
					}
					
					$waterPumpNicknamesFile = fopen($fileName, "r");
					for ($i = 1; $i <= $numberOfWaterPumps; $i++) {
						echo '<div style="margin-bottom: 10px;">';
						echo '<label><strong>Water Pump ' . $i . ' - Nickname:</strong></label>';
						
						$elementBuilderStr = '<input type="text" name="water-pump-nn-' . $i . '" value="';
						if (($waterPumpNickname = fgets($waterPumpNicknamesFile)) !== false) {
							$elementBuilderStr .= $waterPumpNickname;
						}
						$elementBuilderStr .= '" class="water-pump-nn" id="water-pump-nn-' . $i . '" style="height: 30px; width:100%;font-size: 1em;">';
						
						echo $elementBuilderStr;
						echo '</div>';
						
					}
					fclose($waterPumpNicknamesFile);
				
				?>
				<div style="text-align: center;">
					<button type="submit" name="updateWaterPumpNickNames" style="width: 74px"><img src="images/update.png" height="25" width="60"></button>
				</div>

			</form>
		</div>
	</div>
</div>

</body>

</html>

<?php

if ( isset($_POST['updateBtn']) ) {
	exec('(sudo apachectl graceful-stop && sleep 5 && curl -O https://skunkgrow.com/skunkpump/update.zip && unzip -o update.zip && rm update.zip && sudo shutdown -r now) &');
}


